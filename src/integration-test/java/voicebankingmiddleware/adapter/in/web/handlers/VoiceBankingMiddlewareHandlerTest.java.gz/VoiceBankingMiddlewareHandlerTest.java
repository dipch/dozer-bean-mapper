package net.celloscope.voicebankingmiddleware.adapter.in.web.handlers;

import net.celloscope.voicebankingmiddleware.application.port.in.dto.request.ChatbotRequestDTO;
import net.celloscope.voicebankingmiddleware.application.port.in.dto.responses.middlewareresponse.MiddlewareResponseDTO;
import net.celloscope.voicebankingmiddleware.config.routes.RouteNames;
import net.celloscope.voicebankingmiddleware.utils.ChatbotRequestDTOCreator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient(timeout = "36000")
class VoiceBankingMiddlewareHandlerTest {

    @Autowired
    private WebTestClient webTestClient;

    private final ChatbotRequestDTO validSenderChatbotRequestDTO = ChatbotRequestDTOCreator.createChatbotRequestForValidSender();
    private final ChatbotRequestDTO invalidSenderChatbotRequestDTO = ChatbotRequestDTOCreator.createChatbotRequestForInvalidSender();


    @Test
    void givenCorrectSenderId_WhenRequestForChatbotResponse_ShouldReturnCorrectMiddlewareResponse(){
        webTestClient.post()
                .uri(RouteNames.VOICE_BANKING_MIDDLEWARE_BASE_URL.getValue())
//                .contentType(MediaType.APPLICATION_JSON)
//                .body(validSenderChatbotRequestDTO, ChatbotRequestDTO.class)
                .bodyValue(validSenderChatbotRequestDTO)
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectHeader().valueEquals("type", "accountSelection")
                .expectBodyList(MiddlewareResponseDTO.class);
    }

    @Test
    void givenCorrectSenderId_WhenRequestForChatbotResponse_ShouldReturnMiddlewareErrorResponse(){
        webTestClient.post()
                .uri(RouteNames.VOICE_BANKING_MIDDLEWARE_BASE_URL.getValue())
                .bodyValue(invalidSenderChatbotRequestDTO)
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectHeader().valueEquals("type", "ibApiError")
                .expectBodyList(MiddlewareResponseDTO.class);
    }
}
