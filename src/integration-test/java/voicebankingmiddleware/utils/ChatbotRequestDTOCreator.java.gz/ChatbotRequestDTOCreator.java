package net.celloscope.voicebankingmiddleware.utils;

import net.celloscope.voicebankingmiddleware.application.port.in.dto.request.ChatbotRequestDTO;

public class ChatbotRequestDTOCreator {

    public static ChatbotRequestDTO createChatbotRequestForValidSender(){
        return ChatbotRequestDTO.builder()
                .sender("bavCf7OB476048i5wAkOm9B8ZiI|session_id113")
                .message("ব্যালেন্স জানতে চাই")
                .build();
    }

    public static ChatbotRequestDTO createChatbotRequestForInvalidSender(){
        return ChatbotRequestDTO.builder()
                .sender("bavCf7OB476048i5wAkOm9B8ZiIl|session_id113")
                .message("ব্যালেন্স জানতে চাই")
                .build();
    }
}
